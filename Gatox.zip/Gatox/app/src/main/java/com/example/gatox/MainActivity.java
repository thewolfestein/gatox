package com.example.gatox;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText jugador1;
    private EditText jugador2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        jugador1 = (EditText)findViewById(R.id.nombre1);
        jugador2 = (EditText)findViewById(R.id.nombre2);
    }

    public void button_click(View view){

        String nombre = jugador1.getText().toString();
        String nombre2 = jugador2.getText().toString();

        if(!nombre.equals("")&&!nombre2.equals("")){
            Intent intent = new Intent(this,Juego.class);
            intent.putExtra("jugador1",nombre);
            intent.putExtra("jugador2",nombre2);

            startActivity(intent);

            finish();
        }



    }
}