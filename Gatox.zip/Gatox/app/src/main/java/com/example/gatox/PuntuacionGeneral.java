/*package com.example.gatox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class PuntuacionGeneral extends AppCompatActivity {
    private TextView puntuacionTexto;
    int score;
    int ultima_puntuacion,puntaje1,puntaje2,puntaje3;
    String string_score;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_puntuacion_general);

        puntuacionTexto = (TextView)findViewById(R.id.puntuacion_texto);
        string_score = getIntent().getStringExtra("score");
        score = Integer.parseInt(string_score);
        puntuacionTexto.setText("Score: " + score);

        SharedPreferences preferences = getSharedPreferences("PREFS",0);
        ultima_puntuacion = preferences.getInt("ultimo_score",0);
        puntaje1 = preferences.getInt("puntaje1",0);
        puntaje2 = preferences.getInt("puntaje2",0);

        if(ultima_puntuacion > puntaje2) {
            int aux = puntaje2;
            puntaje2=ultima_puntuacion;
            puntaje3=aux;
        }
        if(ultima_puntuacion > puntaje1) {
            int aux = puntaje1;
            puntaje1=ultima_puntuacion;
            puntaje2=aux;
        }

        puntuacionTexto.setText("Ultimo Score:" + ultima_puntuacion  + "\n" +
                "Primer lugar" + nombrejugador1 + "\n" +
                "Segundo lugar" + nombrejugador2 + "\n" );


        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.mipmap.ic_launcher);


    }

}*/